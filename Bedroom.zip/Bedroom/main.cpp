
#include<windows.h>
#include<GL/glut.h>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
void pile(double xc, double yc,double x,double y){
    glColor3f(1 ,0.270588, 0);
    glBegin(GL_TRIANGLE_STRIP);
        glVertex2f(xc+x,yc+y);
        glVertex2f(xc+y,yc+x);
        glColor3f(0.419608, 0.556863, 0.137255);
        glVertex2f(xc-y,yc+x);
        glVertex2f(xc-x,yc+y);
        glColor3f(0,0,.5);
        glVertex2f(xc-x,yc-y);
        glVertex2f(xc-y,yc-x);
        glVertex2f(xc+y,yc-x);
        glColor3f(0.596078, 0.984314 ,0.596078);
        glVertex2f(xc+x,yc-y);
    glEnd();
    glFlush();

}
void watchp(double xc, double yc,double x,double y){
    glBegin(GL_TRIANGLE_STRIP);
        glVertex2f(xc+x,yc+y);
        glVertex2f(xc+y,yc+x);
        glVertex2f(xc-y,yc+x);
        glVertex2f(xc-x,yc+y);
        glVertex2f(xc-x,yc-y);
        glVertex2f(xc-y,yc-x);
        glVertex2f(xc+y,yc-x);
        glVertex2f(xc+x,yc-y);
    glEnd();
    glFlush();

}

void point(double xc, double yc,double x,double y){
    glColor3f(0 ,1, 0.498039);
    glBegin(GL_TRIANGLE_STRIP);
        glVertex2f(xc+x,yc+y);
        glVertex2f(xc+y,yc+x);
        glColor3f(1 ,0, 0);
        glVertex2f(xc-y,yc+x);
        glVertex2f(xc-x,yc+y);
        glVertex2f(xc-x,yc-y);
        glVertex2f(xc-y,yc-x);
        glVertex2f(xc+y,yc-x);
        glVertex2f(xc+x,yc-y);
    glEnd();
    glFlush();

}
void pil(double xc, double yc ,double r){
    double p,x=0,y;
    p=1-r;
    y=r;
    while(x<y){
        if(p<0){
            x+=.001;
            p=p+.2*x+.001;
        }
        else{
            x+=.001;
            y-=.001;
            p=p+.2*x-.2*y+.001;
        }
        pile(xc,yc,x,y);
    }
}
void watch(double xc, double yc ,double r){
    double p,x=0,y;
    p=1-r;
    y=r;
    while(x<y){
        if(p<0){
            x+=.001;
            p=p+2*x+.001;
        }
        else{
            x+=.001;
            y-=.001;
            p=p+2*x-2*y+.001;
        }
        watchp(xc,yc,x,y);
    }
}
void circle(double xc, double yc ,double r){
    double p,x=0,y;
    p=1-r;
    y=r;
    while(x<y){
        if(p<0){
            x+=.001;
            p=p+2*x+.001;
        }
        else{
            x+=.001;
            y-=.001;
            p=p+2*x-2*y+.001;
        }
        point(xc,yc,x,y);
    }
}


void  flower(float a){
    glColor3f(.1,.1,.1);
    glBegin(GL_POLYGON);
        glVertex2f(.67*a,.10);
        glColor3f(.5,.5,.5);
        glVertex2f(.68*a,.09);
        glVertex2f(.69*a,.08);
        glVertex2f(.70*a,.09);
        glColor3f(1,0,0);
        glVertex2f(.71*a,.10);
        glColor3f(.5,.5,.5);
        glVertex2f(.715*a,.30);
        glColor3f(1,1,1);
        glVertex2f(.665*a,.30);

    glEnd();
    glFlush();
    glColor3f(0,0,0);
    glBegin(GL_LINES);
        glVertex2f(.708*a,.30);
        glVertex2f(.74*a,.5);
        glVertex2f(.702*a,.30);
        glVertex2f(.71*a,.45);
        glVertex2f(.69*a,.30);
        glVertex2f(.68*a,.55);
        glVertex2f(.675*a,.30);
        glVertex2f(.65*a,.50);


    glEnd();
    glFlush();



}

void mydisplay(){
    glClear(GL_COLOR_BUFFER_BIT);
 //main window
glColor3f(0.282,0.239,0.545);
glBegin(GL_POLYGON);
	glVertex2f(-1.0,-1.0);
	glVertex2f(-1.0,1.0);
	glVertex2f(1.0,1.0);
	glVertex2f(1.0,-1.0);
glEnd();
glFlush();
    glColor3f(0.941176, 0.972549, 1);
    glBegin(GL_POLYGON);
        glVertex2f(0.0,0.0);
        glColor3f(0.980392, 0.921569, 0.843137);
        glVertex2f(0.0,1.0);
        glColor3f(0.498039, 1, 0.831373);
        glVertex2f(1.0,1.0);
        glColor3f(0.541176, 0.168627, 0.886275);
        glVertex2f(1.0,0.0);
    glEnd();
    glFlush();
    glColor3f(0.0, 0,0);
    glBegin(GL_POLYGON);
        glVertex2f(-1,0.0);
        glColor3f(0.490196, 0.619608, 0.752941);
        glVertex2f(1,0);
        glColor3f(0.666667 ,0.666667, 0.666667);
        glVertex2f(1.0,-1.0);
        glColor3f(0.0980392 ,0.0980392, 0.439216);
        glVertex2f(-1.0,-1.0);
    glEnd();
    glFlush();


    glBegin(GL_LINES);
    glColor3f(0,0,0);
        float m=0,x1=-1,n=.95,i;
        for(i=1;i<=20;i++,n-=.05){
            glVertex2f(x1,n);
            glVertex2f(m,n);
       }
    glEnd();
    glFlush();

    glColor3f(0.627451, 0.321569 ,0.176471);
    glBegin(GL_POLYGON);
      glVertex2f(-0.60,0.55);
      glVertex2f(0.60,0.55);
      glVertex2f(0.60,0.15);
      glVertex2f(-0.60,0.15);

    glEnd();
    glFlush();
    glColor3f(1, 1 ,1);
    glBegin(GL_POLYGON);
      glVertex2f(-0.80,0.15);
      glVertex2f(0.80,0.15);
      glColor3f(0.545098, 0.270588 ,0.0745098);
      glVertex2f(0.85,0.05);
      glVertex2f(-0.85,0.05);
    glEnd();
    glFlush();
    glColor3f(0.627451, 0.321569 ,0.176471);
    glBegin(GL_POLYGON);
      glVertex2f(-.85,0.05);
      glVertex2f(0.85,0.05);
      glVertex2f(0.85,0.0);
      glVertex2f(-0.85,0.0);
    glEnd();
    glFlush();

    glColor3f(0,0,0);
    glBegin(GL_LINES);
        glVertex2f(-.60,.485);
        glVertex2f(.60,.485);
        glVertex2f(-.60,.35);
        glVertex2f(.60,.35);
    glEnd();
    glFlush();

    //point 1
    glColor3f(0.627451, 0.321569 ,0.176471);
    glBegin(GL_POLYGON);
      glVertex2f(-0.50,-.80);
      glVertex2f(-0.50,-0.60);
      glVertex2f(0.50,-0.60);
      glVertex2f(0.50,-0.80);
    glEnd();
    glFlush();
//point 5
    glColor3f(0.803922, 0.521569, 0.247059);
    glBegin(GL_POLYGON);
        glVertex2f(-0.35,0.20);
        glVertex2f(-0.35,0.45);
        glVertex2f(0.40,0.45);
        glVertex2f(0.40,0.20);

    glEnd();
    glFlush();

  //point 2
    glColor3f(0,0,0);
    glBegin(GL_POLYGON);
      glVertex2f(-0.50,-0.60);
      glVertex2f(-0.35,0.20);
      glColor3f(0.858824, 0.439216, 0.576471);
      glVertex2f(0.40,0.20);
      glVertex2f(0.50,-0.60);
  glEnd();
  glFlush();

    pil(-.15,.2,.15);
    pil(.16,.2,.15);
//wairdrop()
    glColor3f(0.545098, 0.270588 ,0.0745098);
    glBegin(GL_POLYGON);
        glVertex2f(-1,-0.90);
        glVertex2f(-0.85,-0.90);
        glVertex2f(-0.85,-0.60);
        glVertex2f(-1,-0.60);
    glEnd();
    glFlush();
    glColor3f(0.545098, 0.270588 ,0.0745098);
    glBegin(GL_POLYGON);
        glVertex2f(-1,-0.60);
        glVertex2f(-.98,-0.10);
        glColor3f(0.960784 ,1, 0.980392);
        glVertex2f(-0.85,-0.10);
        glVertex2f(-0.85,-0.60);

    glEnd();
    glFlush();
    glColor3f(0.545098, 0.270588 ,0.0745098);
    glBegin(GL_POLYGON);
        glVertex2f(-0.85,-0.90);
        glVertex2f(-0.85,-0.60);
        glColor3f(1 ,0.752941 ,0.796078);
        glVertex2f(-0.85,-0.10);
        glVertex2f(-0.82,-0.30);

    glEnd();
    glFlush();
    glColor3f(1,1,1);
    glBegin(GL_LINES);
        glVertex2f(-0.85,-0.35);
        glVertex2f(-0.83,-0.60);
    glEnd();
    glFlush();
    flower(1);
    flower(-1);
    glColor3f(0,0,0);
    watch(.5,.8,.13);
    glColor3f(1,1,1);
    watch(.5,.8,.12);
    glColor3f(0,0,0);
    glBegin(GL_LINES);
        glVertex2f(.5,.8);
        glVertex2f(.5,.90);
        glVertex2f(.5,.8);
        glVertex2f(.55,.88);
        glVertex2f(.5,.8);
        glVertex2f(.48,.70);
    glEnd();
    glFlush();

    circle(.74,.5,.05);
    circle(.71,.45,.05);
    circle(.68,.55,.05);
    circle(.65,.5,.05);
    circle(-.74,.5,.05);
    circle(-.71,.45,.05);
    circle(-.68,.55,.05);
    circle(-.65,.5,.05);

}



void init(void){
    glClearColor(0.0,0.0,0.0,0.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(1.0,1.0,2.0,2.0,-1.0,1.0);
}

int main(int argc,char** argv){
    glutInit(&argc,argv);
    glutInitWindowSize(1200,700);
    glutInitWindowPosition(10,10);
    glutCreateWindow("My Simple window");
    init();
    glutDisplayFunc(mydisplay);
    glutMainLoop();

    return 0;
}
