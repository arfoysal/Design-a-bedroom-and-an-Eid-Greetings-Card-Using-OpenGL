
#ifdef __APPLE__
#else
#endif
#include <stdlib.h>
#include<stdio.h>
#include<iostream>
#include<windows.h>
#include<GL/glut.h>
#include<math.h>

void drawText(char ch[],float xpos, float ypos)
{
    int numofchar = strlen(ch);
    glLoadIdentity ();
    glRasterPos2f( xpos , ypos);
    for (int i = 0; i <= numofchar - 1; i++)
    {

    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, ch[i]);
    }
    //glEnd();
    glFlush();
}

void mydisplay(){
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.498039, 1, 0);
    glBegin(GL_POLYGON);
        glVertex2f(-1.0,-1.0);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);
        glVertex2f(1.0,-1.0);
    glEnd();
    glFlush();
    glColor3f( 0.541, 0.168, 0.886);
    glBegin(GL_POLYGON);
        glVertex2f(-.95,-.95);
        glVertex2f(-.95,.95);
        glVertex2f(.95,.95);
        glVertex2f(.95,-.95);
    glEnd();
    glFlush();
    glColor3f( 0 ,0,1);
    glBegin(GL_POLYGON);
        glVertex2f(-.9,-.9);
        glVertex2f(-.9,.9);
        glVertex2f(.9,.9);
        glVertex2f(.9,-.9);
    glEnd();
    glFlush();
    glColor3f( 0.941176, 0.501961,0.501961);
    glBegin(GL_POLYGON);
        glVertex2f(-.85,-.85);
        glVertex2f(-.85,.85);
        glVertex2f(.85,.85);
        glVertex2f(.85,-.85);
    glEnd();
    glFlush();
    glColor3f( 1, 1, 0.878);
    glBegin(GL_POLYGON);
        glVertex2f(-.8,-.8);
        glColor3f(  0.498039, 1 ,0);
        glVertex2f(-.8,.8);
        glColor3f(  0.666667, 0.666667, 0.666667);
        glVertex2f(.8,.8);
        glColor3f(  1, 0.270588, 0);
        glVertex2f(.8,-.8);
    glEnd();
    glFlush();
    //box

    glBegin(GL_POLYGON);
        glColor3f( 0.392157, 0.584314, 0.929412);
        glVertex2f(-.5,-.75);
        glVertex2f(-.5,-.40);
        glColor3f(0.647059, 0.164706 ,0.164706);
        glVertex2f(.5,-.40);
        glVertex2f(.5,-.75);
    glEnd();
    glFlush();
    glColor3f( .05, 0, 0);
    //ground line
    glBegin(GL_LINES);
        glVertex2f(-.70,-.75);
        glVertex2f(.65,-.75);
    glEnd();
    glFlush();
    glColor3f( 0, 1, 1);
    glBegin(GL_POLYGON);
        glColor3f( 0, 1, 1);
        glVertex2f(-.45,-.75);
        glVertex2f(-.45,-.45);
        glColor3f( 1 ,0.980392 ,0.941176);
        glVertex2f(-.16,-.45);
        glVertex2f(-.16,-.75);
    glEnd();
    glFlush();
    glBegin(GL_POLYGON);
        glColor3f( 0, 1, 1);
        glVertex2f(-.15,-.75);
        glVertex2f(-.15,-.45);
        glColor3f( 1 ,0.980392 ,0.941176);
        glVertex2f(.14,-.45);
        glVertex2f(.14,-.75);
    glEnd();
    glFlush();

    glBegin(GL_POLYGON);
        glColor3f( 0, 1, 1);
        glVertex2f(.15,-.75);
        glVertex2f(.15,-.45);
        glColor3f( 1 ,0.980392 ,0.941176);
        glVertex2f(.44,-.45);
        glVertex2f(.44,-.75);
    glEnd();
    glFlush();

    glColor3f( 1,0 , 0);
    glBegin(GL_POLYGON);
        glVertex2f(-.45,-.45);
        glVertex2f(-.16,-.45);
        glVertex2f(-.16,-.46);
        glVertex2f(-.45,-.46);

    glEnd();
    glFlush();
    glColor3f( 1,0 , 0);
    glBegin(GL_POLYGON);
        glVertex2f(-.15,-.45);
        glVertex2f(.14,-.45);
        glVertex2f(.14,-.46);
        glVertex2f(-.15,-.46);
    glEnd();
    glFlush();
    glColor3f( 1,0 , 0);
    glBegin(GL_POLYGON);
        glVertex2f(.15,-.45);
        glVertex2f(.44,-.45);
        glVertex2f(.44,-.46);
        glVertex2f(.15,-.46);
    glEnd();
    glFlush();
    glColor3f( 0,.50 , 0);
    glBegin(GL_TRIANGLES );
        glVertex2f(.295,-.46);
        glVertex2f(.44,-.46);
        glVertex2f(.44,-.605);
    glEnd();
    glFlush();
    glColor3f( 0,.50 , 0);
    glBegin(GL_TRIANGLES );
        glVertex2f(.295,-.46);
        glVertex2f(.15,-.46);
        glVertex2f(.15,-.6);
    glEnd();
    glFlush();
    glColor3f( 0,.50 , 0);
    glBegin(GL_TRIANGLES );
        glVertex2f(-.005,-.46);
        glVertex2f(.14,-.46);
        glVertex2f(.14,-.6);
    glEnd();
    glFlush();
    glColor3f( 0,.50 , 0);
    glBegin(GL_TRIANGLES );
        glVertex2f(-.005,-.46);
        glVertex2f(-.15,-.46);
        glVertex2f(-.15,-.6);
    glEnd();
    glFlush();
    glColor3f( 0,.50 , 0);
    glBegin(GL_TRIANGLES );
        glVertex2f(-.31,-.46);
        glVertex2f(-.16,-.46);
        glVertex2f(-.16,-.6);
    glEnd();
    glFlush();
    glColor3f( 0,.50 , 0);
    glBegin(GL_TRIANGLES );
        glVertex2f(-.31,-.46);
        glVertex2f(-.45,-.46);
        glVertex2f(-.45,-.6);
    glEnd();
    glFlush();

    //miner
    glBegin(GL_POLYGON);
        glColor3f(0.960784, 1 ,0.980392);
        glVertex2f(-.70,-.75);
        glVertex2f(-.70,0);
        glColor3f(0.698039 ,0.133333, 0.133333);
        glVertex2f(-.51,0);
        glVertex2f(-.51,-.75);
    glEnd();
    glFlush();
    glBegin(GL_POLYGON);
        glColor3f(0.960784, 1 ,0.980392);
        glVertex2f(-.70,0);
        glVertex2f(-.77,.05);
        glColor3f(0.698039 ,0.133333, 0.133333);
        glVertex2f(-.44,.05);
        glVertex2f(-.51,0);
    glEnd();
    glFlush();

    glBegin(GL_POLYGON);
        glColor3f(0.960784 ,1 ,0.980392);
        glVertex2f(-.69,.05);
        glVertex2f(-.69,.35);
        glColor3f(0.698039, 0.133333, 0.133333);
        glVertex2f(-.52,.35);
        glVertex2f(-.52,.05);
    glEnd();
    glFlush();

    glBegin(GL_POLYGON);
        glColor3f(0.960784, 1 ,0.980392);
        glVertex2f(-.69,.35);
        glVertex2f(-.76,.35);
        glVertex2f(-.69,.40);
        glColor3f(0.698039 ,0.133333, 0.133333);
        glVertex2f(-.52,.40);
        glVertex2f(-.45,.35);
    glEnd();
    glFlush();
    glBegin(GL_POLYGON);

        glColor3f(0.960784, 1 ,0.980392);
        glVertex2f(-.66,.40);
        glVertex2f(-.74,.50);
        glVertex2f(-.60,.65);
        glColor3f(0.698039 ,0.133333, 0.133333);
        glVertex2f(-.48,.50);
        glVertex2f(-.55,.40);

    glEnd();
    glFlush();
    float radius = .4f;
    glBegin(GL_TRIANGLE_FAN);
        for(double i=0;i<3.1416;){
            glColor3f(0.698039 ,0.133333, 0.133333);
            glVertex2f(radius*cosf(i),radius*sinf(i)-.4);
            i+=3.1416/100;
            glColor3f(0.960784, 1 ,0.980392);
            glVertex2f(radius*cosf(i),radius*sinf(i)-.4);
        }
    glEnd();
    glFlush();
    glColor3f(0,0, 0);
    drawText("May you find success in all your endeavors",-.65,.70);
    drawText("and may Allah's (Subhanahu Wa Ta'ala)",-.55,.62);
    drawText("blessings always be with you.",-.45,.54);
    drawText("(Ameen)",.30,.46);
    drawText("Eid Mubarak!",-.35,.30);
    drawText("to you and your loved ones...",-.20,.22);



}
void init(void){
    glClearColor(0.0,0.0,0.0,0.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(1.0,1.0,2.0,2.0,-1.0,1.0);
}

int main(int argc,char** argv){
    glutInit(&argc,argv);
    glutInitWindowSize(500,700);
    glutInitWindowPosition(10,10);
    glutCreateWindow("My Simple window");
    init();
    glutDisplayFunc(mydisplay);
    glutMainLoop();

    return 0;
}
